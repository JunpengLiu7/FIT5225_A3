from django.db import connection

print(connection.queries)

