settings.py -> create database and config database
mydb.py -> database connections

source website\webenv\bin\activate